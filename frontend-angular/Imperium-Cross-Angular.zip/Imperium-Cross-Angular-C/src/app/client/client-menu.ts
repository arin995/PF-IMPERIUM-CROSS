export const CLIENT_MENU = [
  { label: 'Mi rutina', path: 'mi-rutina', icon: 'bi-activity' },
  { label: 'Perfil', path: 'perfil', icon: 'bi-person' },
  { label: 'Productos', path: 'productos', icon: 'bi-bag' },
  { label: 'Pagos', path: 'pagos', icon: 'bi-credit-card' },
  { label: 'NutriAI', path: 'nutricion', icon: 'bi-stars' }
];
