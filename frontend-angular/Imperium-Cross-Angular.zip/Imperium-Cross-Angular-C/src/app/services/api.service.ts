import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private readonly baseUrl = environment.apiUrl;
  constructor(private http: HttpClient) {}

  get<T>(resource: string): Observable<T> { return this.http.get<T>(this.endpoint(resource)); }
  post<T>(resource: string, body: unknown): Observable<T> { return this.http.post<T>(this.endpoint(resource), body); }
  put<T>(resource: string, body: unknown): Observable<T> { return this.http.put<T>(this.endpoint(resource), body); }
  delete<T>(resource: string): Observable<T> { return this.http.delete<T>(this.endpoint(resource)); }

  private endpoint(resource: string): string { return `${this.baseUrl}/${resource.replace(/^\//, '')}`; }
}
