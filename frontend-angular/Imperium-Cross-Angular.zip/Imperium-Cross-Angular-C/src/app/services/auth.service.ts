import { Injectable, signal } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';

export type UserRole = 'admin' | 'recepcion' | 'entrenador' | 'cliente';
export interface SessionUser { name: string; role: UserRole; plan?: string; }

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly storageKey = 'imperium-demo-user';
  readonly user = signal<SessionUser | null>(this.readUser());
  readonly currentUser$ = new BehaviorSubject<SessionUser | null>(this.user());

  constructor(private router: Router) {}

  login(name: string, role: UserRole): void {
    const cleanName = name.trim() || this.defaultName(role);
    const user: SessionUser = { name: cleanName, role, plan: role === 'cliente' ? 'Premium' : this.roleLabel(role) };
    localStorage.setItem(this.storageKey, JSON.stringify(user));
    this.user.set(user);
    this.currentUser$.next(user);
    const landingSection: Record<UserRole, string> = { admin: 'dashboard', recepcion: 'clientes', entrenador: 'mis-clientes', cliente: 'mi-rutina' };
    void this.router.navigate([`/${role}/${landingSection[role]}`]);
  }

  logout(): void {
    localStorage.removeItem(this.storageKey);
    this.user.set(null);
    this.currentUser$.next(null);
    void this.router.navigate(['/login']);
  }

  roleLabel(role: UserRole): string {
    return ({ admin: 'Administrador', recepcion: 'Recepcionista', entrenador: 'Entrenador', cliente: 'Cliente' })[role];
  }

  private defaultName(role: UserRole): string {
    return ({ admin: 'Lin Pacheco', recepcion: 'Milagros León', entrenador: 'Pedro Navarro', cliente: 'Melani Camacho' })[role];
  }

  private readUser(): SessionUser | null {
    try {
      const raw = localStorage.getItem(this.storageKey);
      return raw ? JSON.parse(raw) as SessionUser : null;
    } catch { return null; }
  }
}
