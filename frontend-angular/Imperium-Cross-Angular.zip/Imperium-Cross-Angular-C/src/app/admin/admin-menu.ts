export const ADMIN_MENU = [
  { label: 'Dashboard', path: 'dashboard', icon: 'bi-grid-1x2' },
  { label: 'Usuarios', path: 'usuarios', icon: 'bi-people' },
  { label: 'Clientes', path: 'clientes', icon: 'bi-person-vcard' },
  { label: 'Membresías', path: 'membresias', icon: 'bi-card-checklist' },
  { label: 'Productos', path: 'productos', icon: 'bi-box-seam' }
];
