import { Component } from '@angular/core';

@Component({
  selector: 'app-brand', standalone: true,
  template: '<span class="brand-mark" aria-hidden="true">✦</span><span>IMPERIUM<small>CROSS</small></span>'
})
export class BrandComponent {}
