import { Routes } from '@angular/router';
import { roleGuard } from './core/guards/auth.guard';
import { LandingComponent } from './landing/landing.component';
import { LoginComponent } from './auth/login.component';
import { WorkspaceComponent } from './workspace/workspace.component';

export const routes: Routes = [
  { path: '', component: LandingComponent, title: 'Imperium Cross | Supera tus límites' },
  { path: 'login', component: LoginComponent, title: 'Iniciar sesión | Imperium Cross' },
  { path: ':role', redirectTo: ':role/dashboard', pathMatch: 'full' },
  { path: ':role/:section', component: WorkspaceComponent, canActivate: [roleGuard] },
  { path: '**', redirectTo: '' }
];
