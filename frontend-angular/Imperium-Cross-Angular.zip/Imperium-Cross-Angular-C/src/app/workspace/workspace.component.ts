import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService, UserRole } from '../services/auth.service';
import { ADMIN_MENU } from '../admin/admin-menu';
import { RECEPTION_MENU } from '../reception/reception-menu';
import { TRAINER_MENU } from '../trainer/trainer-menu';
import { CLIENT_MENU } from '../client/client-menu';
import { BrandComponent } from '../shared/components/brand.component';

interface MenuItem { label: string; path: string; icon: string; }
interface Column { label: string; key: string; }

@Component({
  selector: 'app-workspace', standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, RouterLinkActive, BrandComponent],
  template: `
    <div class="workspace">
      <aside class="sidebar" [class.sidebar-open]="mobileMenu">
        <a class="brand sidebar-brand" routerLink="/"><app-brand /></a>
        <span class="nav-caption">ESPACIO DE {{ roleName | uppercase }}</span>
        <nav class="side-menu"><a *ngFor="let item of menu" [routerLink]="['/', role, item.path]" routerLinkActive="active" (click)="mobileMenu = false"><i class="bi" [class]="'bi ' + item.icon"></i><span>{{ item.label }}</span></a></nav>
        <div class="sidebar-bottom"><div class="coach-tip"><i class="bi bi-lightning-charge-fill"></i><strong>Un día a la vez.</strong><small>La constancia construye resultados.</small></div><button (click)="auth.logout()"><i class="bi bi-box-arrow-left"></i> Cerrar sesión</button></div>
      </aside>
      <div class="workspace-main">
        <header class="topbar"><button class="mobile-menu-toggle" (click)="mobileMenu = !mobileMenu"><i class="bi bi-list"></i></button><div class="topbar-context"><span>IMPERIUM CROSS</span><i class="bi bi-chevron-right"></i><strong>{{ pageTitle }}</strong></div><div class="topbar-actions"><button class="icon-button notification-button" title="Notificaciones"><i class="bi bi-bell"></i><span></span></button><button class="profile-button" (click)="profileOpen = !profileOpen"><span class="profile-avatar">{{ initials }}</span><span><b>{{ userName }}</b><small>{{ roleName }}<ng-container *ngIf="role === 'cliente'"> · Premium</ng-container></small></span><i class="bi bi-chevron-down"></i></button><div class="profile-popover" *ngIf="profileOpen"><button (click)="goProfile()"><i class="bi bi-person"></i> Mi perfil</button><button (click)="auth.logout()"><i class="bi bi-box-arrow-right"></i> Cerrar sesión</button></div></div></header>
        <main class="content-area" (click)="profileOpen = false">
          <div class="page-intro"><div><span class="eyebrow">{{ roleName | uppercase }}</span><h1>{{ pageTitle }}</h1><p>{{ pageSubtitle }}</p></div><div class="page-intro-actions" *ngIf="primaryAction"><button class="btn-red" (click)="openModal(primaryAction)"><i class="bi bi-plus-lg"></i> {{ primaryAction }}</button></div></div>

      <ng-container *ngIf="role === 'admin' && section === 'dashboard'; else roleContent">
            <div class="metrics-grid"><article class="metric-card" *ngFor="let metric of metrics"><div class="metric-top"><span>{{ metric.label }}</span><i class="bi" [class]="'bi ' + metric.icon"></i></div><strong>{{ metric.value }}</strong><small class="metric-trend"><i class="bi bi-arrow-up-right"></i> {{ metric.delta }} <span>vs. mes anterior</span></small></article></div>
            <div class="dashboard-grid"><section class="panel revenue-panel"><div class="panel-heading"><div><h2>Ingresos mensuales</h2><p>Matrículas y ventas · 2026</p></div><button class="period-select">Este año <i class="bi bi-chevron-down"></i></button></div><div class="chart"><div class="chart-y"><span>S/ 8k</span><span>S/ 6k</span><span>S/ 4k</span><span>S/ 2k</span><span>S/ 0</span></div><div class="chart-bars"><div *ngFor="let bar of chartBars" class="chart-bar-group"><span class="chart-bar" [style.height.%]="bar.value"></span><small>{{ bar.month }}</small></div></div></div></section><section class="panel activity-panel"><div class="panel-heading"><div><h2>Actividad reciente</h2><p>Últimos movimientos</p></div><button class="text-action">Ver todo</button></div><div class="activity-item" *ngFor="let activity of activities"><span class="activity-dot" [class]="'activity-dot ' + activity.kind"></span><div><strong>{{ activity.title }}</strong><small>{{ activity.detail }}</small></div><time>{{ activity.time }}</time></div></section></div>
            <section class="panel quick-panel"><div class="panel-heading"><div><h2>Accesos rápidos</h2><p>Gestiona el gimnasio desde un solo lugar</p></div></div><div class="quick-actions"><button *ngFor="let item of adminQuickLinks" (click)="navigate(item.path)"><i class="bi" [class]="'bi ' + item.icon"></i><span>{{ item.label }}</span><i class="bi bi-arrow-up-right"></i></button></div></section>
          </ng-container>

          <ng-template #roleContent>
            <ng-container *ngIf="isTableScreen; else specialScreen">
              <section class="panel data-panel">
                <div class="table-toolbar"><div class="search-box"><i class="bi bi-search"></i><input [(ngModel)]="searchTerm" placeholder="{{ searchPlaceholder }}" aria-label="Buscar"></div><div class="table-toolbar-right"><span class="results-count">{{ filteredRows.length }} registros</span><button *ngIf="role === 'recepcion' && section === 'asistencia'" class="btn-outline-red" (click)="openModal('Marcar asistencia')"><i class="bi bi-calendar-check"></i> Marcar asistencia</button></div></div>
                <div class="table-responsive"><table class="table align-middle"><thead><tr><th *ngFor="let col of columns">{{ col.label }}</th><th class="actions-col">Acciones</th></tr></thead><tbody><tr *ngFor="let row of filteredRows; let i = index; trackBy: trackByRecord"><td *ngFor="let col of columns"><span *ngIf="isStatus(row[col.key]); else plainCell" class="status-pill" [ngClass]="statusClass(row[col.key])">{{ row[col.key] }}</span><ng-template #plainCell>{{ row[col.key] }}</ng-template></td><td class="row-actions"><button type="button" class="action-icon view" title="Ver" (click)="rowAction('Ver detalle', row)"><i class="bi bi-eye"></i></button><button type="button" *ngIf="canEditRows" class="action-icon edit" title="Editar" (click)="rowAction('Editar', row)"><i class="bi bi-pencil"></i></button><button type="button" *ngIf="role === 'admin'" class="action-icon delete" title="Eliminar" (click)="rowAction('Eliminar', row)"><i class="bi bi-trash3"></i></button><button type="button" *ngIf="role === 'recepcion' && section === 'membresias'" class="action-icon paid" title="Cobrar" (click)="openModal('Cobrar membresía')"><i class="bi bi-receipt"></i></button><button type="button" *ngIf="role === 'entrenador' && section === 'seguimiento'" class="action-icon paid" title="Agregar seguimiento" (click)="openModal('Registrar seguimiento')"><i class="bi bi-plus-lg"></i></button></td></tr><tr *ngIf="filteredRows.length === 0"><td [attr.colspan]="columns.length + 1" class="empty-state"><i class="bi bi-search"></i><strong>No encontramos resultados</strong><span>Prueba con otro término de búsqueda.</span></td></tr></tbody></table></div>
                <div class="panel-footer"><span>Mostrando {{ filteredRows.length }} de {{ rows.length }} registros</span><div class="pagination"><button disabled><i class="bi bi-chevron-left"></i></button><button class="current">1</button><button disabled><i class="bi bi-chevron-right"></i></button></div></div>
              </section>
            </ng-container>
            <ng-template #specialScreen>
                <ng-container *ngIf="role === 'entrenador' && section === 'ejercicios'; else clientRoutine">
                <div class="catalog-toolbar panel"><div class="search-box"><i class="bi bi-search"></i><input [(ngModel)]="searchTerm" placeholder="Buscar ejercicios"></div><div class="filter-chips"><button *ngFor="let tag of exerciseFilters" [class.selected]="activeFilter === tag" (click)="activeFilter = tag">{{ tag }}</button></div></div><div class="exercise-grid"><article class="exercise-card" *ngFor="let ex of filteredExercises" (click)="selectedExercise = ex"><div class="exercise-art"><img *ngIf="ex.gif; else exerciseIcon" [src]="ex.gif" [alt]="ex.name"><ng-template #exerciseIcon><i class="bi" [class]="'bi ' + ex.icon"></i></ng-template><span>{{ ex.category }}</span></div><div class="exercise-card-body"><strong>{{ ex.name }}</strong><span>{{ ex.group }} · {{ ex.level }}</span></div></article></div>
              </ng-container>
              <ng-template #clientRoutine>
                <ng-container *ngIf="role === 'cliente' && section === 'mi-rutina'; else productScreen">
                  <div class="routine-layout"><section class="panel routine-panel"><div class="routine-banner"><div><span class="eyebrow light">TU RUTINA ACTUAL</span><h2>Tren superior</h2><p>Creada por Pedro Navarro · 4 días por semana</p></div><span class="status-pill status-active">Activa</span></div><div class="routine-exercises"><article class="routine-exercise" *ngFor="let ex of clientExercises" (click)="selectedExercise = ex"><span class="exercise-number">{{ ex.number }}</span><span class="exercise-thumb"><i class="bi bi-person-arms-up"></i></span><span class="exercise-info"><strong>{{ ex.name }}</strong><small>{{ ex.group }} · {{ ex.level }}</small></span><span class="exercise-dose"><b>{{ ex.sets }} × {{ ex.reps }}</b><small>{{ ex.rest }} descanso</small></span><i class="bi bi-chevron-right"></i></article></div></section><aside class="panel progress-panel"><div class="panel-heading"><div><h2>Mi progreso</h2><p>Notas de tu entrenador</p></div><i class="bi bi-activity"></i></div><article class="progress-note" *ngFor="let note of progressNotes"><span>{{ note.date }}</span><strong>{{ note.title }}</strong><p>{{ note.text }}</p></article><button class="btn-outline-red w-100" (click)="navigate('perfil')">Ver mi perfil <i class="bi bi-arrow-right"></i></button></aside></div>
                </ng-container>
              </ng-template>
              <ng-template #productScreen>
                <ng-container *ngIf="(role === 'cliente' || role === 'recepcion') && section === 'productos'; else profileScreen">
                  <div class="product-toolbar panel"><div class="info-banner"><i class="bi bi-info-circle"></i><span><b>{{ role === 'cliente' ? 'Compra presencial en recepción' : 'Punto de venta' }}</b><small>{{ role === 'cliente' ? 'Todos los productos se adquieren en el gimnasio.' : 'Agrega productos a la venta actual.' }}</small></span></div><div class="search-box"><i class="bi bi-search"></i><input [(ngModel)]="searchTerm" placeholder="Buscar productos"></div><div class="filter-chips"><button *ngFor="let tag of productFilters" [class.selected]="activeFilter === tag" (click)="activeFilter = tag">{{ tag }}</button></div></div>
                  <div class="store-layout"><div class="store-grid"><article class="store-card" *ngFor="let product of filteredProducts"><div class="product-visual"><span class="status-pill" [ngClass]="statusClass(product.status)">{{ product.status }}</span><i class="bi" [class]="'bi ' + product.icon"></i></div><strong>{{ product.name }}</strong><span>{{ product.category }}</span><div class="product-price"><b>S/ {{ product.price }}</b><button *ngIf="role === 'recepcion'" class="add-product" (click)="$event.stopPropagation(); addToCart(product)"><i class="bi bi-plus-lg"></i></button></div></article></div><aside *ngIf="role === 'recepcion'" class="panel cart-panel"><div class="panel-heading"><div><h2>Venta actual</h2><p>{{ cartCount }} productos</p></div><i class="bi bi-bag"></i></div><div *ngFor="let item of cart" class="cart-item"><span>{{ item.name }}<small>S/ {{ item.price }} c/u</small></span><div><button (click)="changeQuantity(item, -1)">−</button><b>{{ item.quantity }}</b><button (click)="changeQuantity(item, 1)">+</button></div></div><div class="cart-total"><span>Total a pagar</span><strong>S/ {{ cartTotal.toFixed(2) }}</strong></div><button class="btn-red w-100" [disabled]="!cart.length" (click)="openModal('Registrar venta')">Cobrar venta</button></aside></div>
                </ng-container>
              </ng-template>
              <ng-template #profileScreen>
                <ng-container *ngIf="role === 'cliente' && section === 'perfil'; else paymentScreen">
                  <div class="profile-dashboard"><section class="panel member-card"><div class="member-hero"><span class="profile-avatar large">{{ initials }}</span><div><h2>{{ userName }}</h2><p>{{ userName.toLowerCase().replace(' ', '.') }}@hotmail.com</p><span class="status-pill status-active">{{ user?.plan }}</span></div><button class="action-icon edit" (click)="openModal('Editar mis datos')"><i class="bi bi-pencil"></i></button></div><div class="profile-cards"><article><span>Mi objetivo</span><strong>Ganar masa muscular</strong><small>Fecha de registro · 07/09/2026</small></article><article><span>Membresía</span><strong>Plan {{ user?.plan }}</strong><small>Estado <b class="status-pill status-active">Activa</b></small><small>Próximo vencimiento · 07/10/2026</small></article><article><span>Mi entrenador</span><strong><span class="mini-avatar">PN</span> Pedro Navarro</strong><small>Entrenador personal</small></article><article><span>Mi asistencia</span><strong>12 <small>este mes</small> · 47 <small>total</small></strong><small>Última visita · Hoy</small></article></div><div class="membership-actions"><div><span>Próximo vencimiento</span><strong>07/10/2026</strong><small>Renovación de membresía</small></div><button class="btn-red" (click)="navigate('pagos')"><i class="bi bi-credit-card"></i> Pagar renovación</button><button class="btn-outline-red" (click)="navigate('pagos')">Ver historial de pagos</button></div></section></div>
                </ng-container>
              </ng-template>
              <ng-template #paymentScreen>
                <ng-container *ngIf="role === 'cliente' && section === 'pagos'; else nutritionScreen">
                  <section class="panel payment-panel"><div class="panel-heading"><div><h2>Pagos</h2><p>Paga tu membresía y consulta tu historial</p></div></div><div class="payment-methods"><button [class.chosen]="paymentMethod === 'Tarjeta'" (click)="paymentMethod = 'Tarjeta'"><i class="bi bi-credit-card"></i><span><strong>Tarjeta</strong><small>Paga de forma segura con tu tarjeta de crédito o débito.</small></span><i class="bi" [class.bi-circle]="paymentMethod !== 'Tarjeta'" [class.bi-record-circle-fill]="paymentMethod === 'Tarjeta'"></i></button><button [class.chosen]="paymentMethod === 'Yape'" (click)="paymentMethod = 'Yape'"><i class="bi bi-phone"></i><span><strong>Yape</strong><small>Realiza tu pago al instante con Yape.</small></span><i class="bi" [class.bi-circle]="paymentMethod !== 'Yape'" [class.bi-record-circle-fill]="paymentMethod === 'Yape'"></i></button></div><div class="cash-note"><i class="bi bi-info-circle"></i> ¿Prefieres pagar en efectivo? Acércate a recepción.</div><div class="pay-total"><div><span>Monto a pagar</span><strong>S/ 69.99</strong><small>Renovación de membresía Premium (1 mes)</small></div><button class="btn-red" (click)="payNow()">Pagar ahora <i class="bi bi-arrow-right"></i></button></div><div class="panel-heading history-heading"><div><h3>Historial de pagos</h3><p>Consulta tus pagos y descarga tus comprobantes</p></div></div><div class="table-responsive"><table class="table"><thead><tr><th>Fecha</th><th>Plan</th><th>Monto</th><th>Método</th><th>Estado</th><th>Comprobante</th></tr></thead><tbody><tr *ngFor="let row of paymentRows"><td>{{ row.date }}</td><td>{{ row.plan }}</td><td>{{ row.amount }}</td><td>{{ row.method }}</td><td><span class="status-pill status-active">Pagado</span></td><td><button class="action-icon view" (click)="toast('Comprobante listo para descargar')"><i class="bi bi-download"></i></button></td></tr></tbody></table></div></section>
                </ng-container>
              </ng-template>
              <ng-template #nutritionScreen>
                    <ng-container *ngIf="role === 'cliente' && section === 'nutricion'; else genericScreen">
                  <section class="nutrition-chat panel"><div class="nutrition-top"><span class="nutrition-icon"><i class="bi bi-stars"></i></span><span><b>NutriAI</b><small>Beneficio de tu plan Premium</small></span><span class="online-dot"></span></div><div class="chat-messages"><div class="ai-welcome"><i class="bi bi-stars"></i><h2>Hola, {{ userName.split(' ')[0] }}.</h2><p>Soy NutriAI, tu asistente de nutrición. ¿Qué te gustaría consultar hoy?</p><span>Tu información se mantiene privada y segura.</span></div><div *ngFor="let message of chatMessages" class="chat-message" [class.user-message]="message.from === 'user'"><span>{{ message.text }}</span></div></div><div class="chat-suggestions"><button (click)="ask('¿Qué debería comer después de entrenar?')">Ideas para después de entrenar</button><button (click)="ask('¿Cuánta proteína necesito?')">Consumo de proteína</button><button (click)="ask('Dame un desayuno saludable')">Desayuno saludable</button></div><form class="chat-input" (ngSubmit)="sendMessage()"><input [(ngModel)]="chatInput" name="chatInput" placeholder="Pregúntale a NutriAI sobre alimentación..." aria-label="Mensaje para NutriAI"><button class="btn-red" type="submit" [disabled]="!chatInput.trim()"><i class="bi bi-send-fill"></i></button></form><small class="nutrition-disclaimer">NutriAI comparte orientación general y no reemplaza la consulta con un profesional de salud.</small></section>
                </ng-container>
              </ng-template>
              <ng-template #genericScreen>
                <div class="routine-layout" *ngIf="role === 'entrenador' && section === 'rutinas'; else genericPanel"><section class="panel data-panel"><div class="table-responsive"><table class="table"><thead><tr><th>Rutina</th><th>N.º ejercicios</th><th>Clientes asignados</th><th>Última edición</th><th>Acciones</th></tr></thead><tbody><tr *ngFor="let row of routineRows"><td><b>{{ row.name }}</b></td><td>{{ row.exercises }}</td><td>{{ row.clients }}</td><td>{{ row.updated }}</td><td class="row-actions"><button class="action-icon view" (click)="rowAction('Ver rutina', row)"><i class="bi bi-eye"></i></button><button class="action-icon edit" (click)="openModal('Editar rutina')"><i class="bi bi-pencil"></i></button><button class="action-icon delete" (click)="removeRoutine(row)"><i class="bi bi-trash3"></i></button></td></tr></tbody></table></div></section><section class="panel routine-builder"><div class="panel-heading"><div><h2>Constructor de rutinas</h2><p>Prepara un plan personalizado para tus clientes</p></div></div><label>Nombre de la rutina</label><input [(ngModel)]="routineName" placeholder="Ej. Tren superior"><label>Agregar ejercicio</label><select [(ngModel)]="selectedExerciseName"><option value="">Selecciona un ejercicio</option><option *ngFor="let ex of exerciseRows">{{ ex.name }}</option></select><div class="builder-row"><input placeholder="Series" [(ngModel)]="builderSets"><input placeholder="Repeticiones" [(ngModel)]="builderReps"><input placeholder="Descanso" [(ngModel)]="builderRest"><button class="action-icon paid" (click)="addRoutineExercise()"><i class="bi bi-plus-lg"></i></button></div><div class="builder-list"><span *ngFor="let ex of builderExercises">{{ ex }} <button (click)="removeBuilderExercise(ex)">×</button></span></div><button class="btn-red w-100" (click)="saveRoutine()">Guardar rutina</button></section></div>
              </ng-template>
              <ng-template #genericPanel><section class="panel data-panel generic-panel"><div class="empty-state" *ngIf="!isTableScreen"><i class="bi bi-tools"></i><strong>{{ pageTitle }} estará disponible aquí</strong><span>Esta sección forma parte de tu espacio Imperium Cross.</span><button class="btn-outline-red" *ngIf="primaryAction" (click)="openModal(primaryAction)">{{ primaryAction }}</button></div></section></ng-template>
            </ng-template>
          </ng-template>
        </main>
      </div>

      <div class="toast-message" *ngIf="toastText"><i class="bi bi-check-circle-fill"></i>{{ toastText }}<button (click)="toastText = ''">×</button></div>
      <div class="modal-backdrop-custom" *ngIf="modalOpen" (click)="modalOpen = false"><section class="app-modal" (click)="$event.stopPropagation()"><button class="modal-close" (click)="modalOpen = false"><i class="bi bi-x-lg"></i></button><span class="eyebrow">IMPERIUM CROSS</span><h2>{{ modalTitle }}</h2><p>{{ modalDescription }}</p><form (ngSubmit)="saveModal()"><label *ngFor="let field of modalFields">{{ field.label }}<ng-container [ngSwitch]="field.type"><select *ngSwitchCase="'select'" [(ngModel)]="formData[field.key]" [name]="field.key"><option value="">Seleccionar</option><option *ngFor="let option of field.options">{{ option }}</option></select><textarea *ngSwitchCase="'textarea'" [(ngModel)]="formData[field.key]" [name]="field.key" [placeholder]="field.placeholder || ''" rows="3"></textarea><input *ngSwitchDefault [type]="field.type || 'text'" [(ngModel)]="formData[field.key]" [name]="field.key" [placeholder]="field.placeholder || ''"></ng-container></label><div class="modal-actions"><button type="button" class="btn-outline-red" (click)="modalOpen = false">Cancelar</button><button type="submit" class="btn-red">{{ modalSubmitLabel }}</button></div></form></section></div>
      <div class="exercise-detail-backdrop" *ngIf="selectedExercise" (click)="selectedExercise = null"><section class="exercise-detail" (click)="$event.stopPropagation()"><button class="modal-close" (click)="selectedExercise = null"><i class="bi bi-x-lg"></i></button><div class="detail-exercise-art"><img *ngIf="selectedExercise.gif; else detailExerciseIcon" [src]="selectedExercise.gif" [alt]="selectedExercise.name"><ng-template #detailExerciseIcon><i class="bi" [class]="'bi ' + selectedExercise.icon"></i></ng-template></div><span class="eyebrow">{{ selectedExercise.category }} · {{ selectedExercise.group }}</span><h2>{{ selectedExercise.name }}</h2><span class="status-pill status-blue">{{ selectedExercise.level || 'Intermedio' }}</span><div class="exercise-stats"><span><b>4</b> series</span><span><b>10</b> repeticiones</span><span><b>60s</b> descanso</span></div><h3>Descripción</h3><p>{{ selectedExercise.description }}</p><h3>Indicaciones</h3><p>{{ selectedExercise.instructions }}</p><button *ngIf="role === 'entrenador'" class="btn-red w-100" (click)="openModal('Editar ejercicio'); selectedExercise = null">Editar ejercicio</button></section></div>
    </div>
  `
})
export class WorkspaceComponent implements OnInit {
  role: UserRole = 'cliente';
  section = 'dashboard';
  mobileMenu = false;
  profileOpen = false;
  searchTerm = '';
  activeFilter = 'Todos';
  modalOpen = false;
  modalTitle = '';
  toastText = '';
  selectedExercise: any = null;
  formData: Record<string, string> = {};
  paymentMethod = 'Tarjeta';
  chatInput = '';
  chatMessages: { text: string; from: string }[] = [];
  routineName = '';
  selectedExerciseName = '';
  builderSets = '';
  builderReps = '';
  builderRest = '';
  builderExercises: string[] = [];
  cart: any[] = [];
  user: any;
  private toastTimer: ReturnType<typeof setTimeout> | undefined;
  private addedRows: Record<string, any[]> = {};
  private rowEdits: Record<string, any> = {};
  private editingKey: string | null = null;
  private cachedModalTitle = '';
  private cachedModalFields: any[] = [];

  constructor(public auth: AuthService, private route: ActivatedRoute, private router: Router) { this.user = this.auth.user(); }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      this.role = (params.get('role') || 'cliente') as UserRole;
      this.section = params.get('section') || 'dashboard';
      if (this.section === 'dashboard' && this.role !== 'admin') {
        const defaultPath: Record<string, string> = { recepcion: 'clientes', entrenador: 'mis-clientes', cliente: 'mi-rutina' };
        void this.router.navigate([`/${this.role}/${defaultPath[this.role]}`], { replaceUrl: true });
      }
    });
  }

  get menu(): MenuItem[] {
    const menus: Record<UserRole, MenuItem[]> = { admin: ADMIN_MENU, recepcion: RECEPTION_MENU, entrenador: TRAINER_MENU, cliente: CLIENT_MENU };
    return menus[this.role];
  }

  get roleName(): string { return this.auth.roleLabel(this.role); }
  get userName(): string { return this.auth.user()?.name || this.user?.name || 'Melani Camacho'; }
  get initials(): string { return this.userName.split(' ').map((part: string) => part[0]).slice(0, 2).join('').toUpperCase(); }
  get pageTitle(): string { return ({ dashboard: 'Dashboard', usuarios: 'Usuarios', clientes: 'Clientes', membresias: 'Membresías y pagos', asistencia: 'Asistencia', productos: this.role === 'cliente' ? 'Productos' : 'Venta de productos', 'mis-clientes': 'Mis clientes', ejercicios: 'Ejercicios', rutinas: 'Rutinas', seguimiento: 'Seguimiento', 'mi-rutina': 'Mi rutina', perfil: 'Mi perfil', pagos: 'Pagos', nutricion: 'NutriAI' } as Record<string, string>)[this.section] || 'Imperium Cross'; }
  get pageSubtitle(): string { return ({ dashboard: 'Resumen general de tu gimnasio.', usuarios: 'Gestiona los usuarios y sus permisos.', clientes: this.role === 'entrenador' ? 'Tienes clientes asignados.' : 'Consulta y gestiona la información de tus clientes.', membresias: 'Administra planes, pagos y renovaciones.', asistencia: 'Control de ingreso al gimnasio.', productos: this.role === 'cliente' ? 'Productos disponibles en recepción.' : 'Consulta el inventario y registra ventas.', 'mis-clientes': 'Revisa el progreso de tus clientes asignados.', ejercicios: 'Biblioteca de ejercicios.', rutinas: 'Crea rutinas y asígnalas a tus clientes.', seguimiento: 'Estado de tus clientes asignados.', 'mi-rutina': 'Tu plan de entrenamiento asignado.', perfil: 'Visualiza tus datos, membresía y asistencia.', pagos: 'Paga tu membresía y consulta tu historial.', nutricion: 'Tu asistente personal de alimentación.' } as Record<string, string>)[this.section] || 'Tu espacio Imperium Cross.'; }
  get primaryAction(): string { return ({ usuarios: 'Agregar usuario', clientes: 'Agregar cliente', membresias: this.role === 'admin' ? 'Agregar plan' : 'Registrar membresía', productos: this.role === 'admin' ? 'Agregar producto' : '', ejercicios: 'Nuevo ejercicio', rutinas: 'Crear rutina', seguimiento: 'Registrar seguimiento' } as Record<string, string>)[this.section] || ''; }
  get isTableScreen(): boolean { return ['usuarios', 'clientes', 'membresias', 'asistencia', 'mis-clientes', 'seguimiento'].includes(this.section) || (this.role === 'admin' && this.section === 'productos'); }
  get canEditRows(): boolean { return this.role === 'admin' || this.role === 'recepcion'; }
  get roleLabel(): string { return this.roleName; }
  get searchPlaceholder(): string { return this.section === 'asistencia' ? 'Buscar por cliente o DNI' : this.role === 'entrenador' ? 'Buscar cliente' : this.role === 'admin' && this.section === 'productos' ? 'Buscar producto' : 'Buscar ' + (this.section === 'usuarios' ? 'usuario' : 'cliente'); }
  get columns(): Column[] {
    const key = `${this.role}:${this.section}`;
    const map: Record<string, Column[]> = {
      'admin:usuarios': [{ label: 'Nombres', key: 'name' }, { label: 'Apellidos', key: 'surname' }, { label: 'Correo', key: 'email' }, { label: 'Rol', key: 'role' }, { label: 'Estado', key: 'status' }],
      'admin:clientes': [{ label: 'Nombres', key: 'name' }, { label: 'Apellidos', key: 'surname' }, { label: 'Plan', key: 'plan' }, { label: 'Vencimiento', key: 'due' }, { label: 'Estado', key: 'status' }],
      'admin:membresias': [{ label: 'Plan', key: 'plan' }, { label: 'Precio', key: 'price' }, { label: 'Duración', key: 'duration' }, { label: 'Estado', key: 'status' }],
      'admin:productos': [{ label: 'Producto', key: 'product' }, { label: 'Categoría', key: 'category' }, { label: 'Precio', key: 'price' }, { label: 'Stock', key: 'stock' }, { label: 'Estado', key: 'status' }],
      'recepcion:clientes': [{ label: 'Nombres', key: 'name' }, { label: 'Apellidos', key: 'surname' }, { label: 'Correo', key: 'email' }, { label: 'Plan', key: 'plan' }, { label: 'Estado', key: 'status' }],
      'recepcion:membresias': [{ label: 'Nombre', key: 'name' }, { label: 'Apellidos', key: 'surname' }, { label: 'Membresía', key: 'plan' }, { label: 'Importe', key: 'price' }, { label: 'Método', key: 'method' }, { label: 'Estado', key: 'status' }],
      'recepcion:asistencia': [{ label: 'Nombre', key: 'name' }, { label: 'Apellidos', key: 'surname' }, { label: 'Plan', key: 'plan' }, { label: 'Fecha', key: 'date' }, { label: 'Hora', key: 'time' }, { label: 'Asistencia', key: 'status' }],
      'entrenador:mis-clientes': [{ label: 'Nombres', key: 'name' }, { label: 'Apellidos', key: 'surname' }, { label: 'Rutina actual', key: 'routine' }, { label: 'Último seguimiento', key: 'last' }],
      'entrenador:seguimiento': [{ label: 'Cliente', key: 'name' }, { label: 'Rutina', key: 'routine' }, { label: 'Última nota', key: 'note' }, { label: 'Fecha', key: 'date' }, { label: 'Estado', key: 'status' }]
    };
    return map[key] || [];
  }
  get rows(): any[] {
    const key = `${this.role}:${this.section}`;
    const users = [
      { name: 'Mario', surname: 'Bautista', email: 'mario@imperium.com', role: 'Administrador', status: 'Activo', plan: 'Premium', due: '15/11/2026' },
      { name: 'Milagros', surname: 'León', email: 'milagros@imperium.com', role: 'Recepcionista', status: 'Activo', plan: 'Básico', due: '28/11/2026' },
      { name: 'Pedro', surname: 'Navarro', email: 'pedro@imperium.com', role: 'Entrenador', status: 'Activo', plan: 'Premium', due: '24/10/2026' },
      { name: 'Melani', surname: 'Camacho', email: 'melani@hotmail.com', role: 'Cliente', status: 'Inactivo', plan: 'Pro', due: '24/10/2026' }
    ];
    const clients = [users[3], { name: 'Ana', surname: 'Ramírez', email: 'ana@hotmail.com', role: 'Cliente', status: 'Activo', plan: 'Básico', due: '28/11/2026' }, { name: 'Luis', surname: 'Torres', email: 'luis@hotmail.com', role: 'Cliente', status: 'Vencido', plan: 'Premium', due: '15/09/2026' }, { name: 'Carolina', surname: 'Rivas', email: 'carolina@hotmail.com', role: 'Cliente', status: 'Pendiente', plan: 'Pro', due: '01/10/2026' }];
    const records: Record<string, any[]> = {
      'admin:usuarios': users,
      'admin:clientes': clients,
      'admin:membresias': [{ plan: 'Plan Básico', price: 'S/ 39.99', duration: '30 días', status: 'Activo' }, { plan: 'Plan Premium', price: 'S/ 69.99', duration: '30 días', status: 'Activo' }, { plan: 'Plan Pro', price: 'S/ 99.99', duration: '30 días', status: 'Activo' }],
      'admin:productos': [{ product: 'Polo deportivo azul', category: 'Ropa', price: 'S/ 59.00', stock: 24, status: 'Disponible' }, { product: 'Proteína Whey', category: 'Suplementos', price: 'S/ 149.00', stock: 12, status: 'Disponible' }, { product: 'Mochila grande roja', category: 'Accesorios', price: 'S/ 75.00', stock: 5, status: 'Stock bajo' }, { product: 'Paquete barras proteína', category: 'Snacks', price: 'S/ 25.00', stock: 0, status: 'Agotado' }],
      'recepcion:clientes': clients,
      'recepcion:membresias': [{ name: 'Mario', surname: 'Bautista', plan: 'Premium', price: 'S/ 69.99', method: 'Efectivo', status: 'Pendiente' }, { name: 'Milagros', surname: 'León', plan: 'Básico', price: 'S/ 39.99', method: 'Efectivo', status: 'Pagado' }, { name: 'Ana', surname: 'Ramírez', plan: 'Premium', price: 'S/ 69.99', method: 'Tarjeta', status: 'Pagado' }, { name: 'Carolina', surname: 'Rivas', plan: 'Pro', price: 'S/ 99.99', method: 'Yape', status: 'Vencido' }],
      'recepcion:asistencia': [{ name: 'Mario', surname: 'Bautista', plan: 'Premium', date: '2026-10-29', time: '07:30', status: 'Ingreso' }, { name: 'Milagros', surname: 'León', plan: 'Básico', date: '2026-10-29', time: '08:10', status: 'Ingreso' }, { name: 'Ana', surname: 'Ramírez', plan: 'Básico', date: '2026-10-28', time: '09:15', status: 'Ingreso' }, { name: 'Luis', surname: 'Torres', plan: 'Pro', date: '2026-10-28', time: '18:40', status: 'Vencido' }],
      'entrenador:mis-clientes': [{ name: 'Melani', surname: 'Camacho', routine: 'Tren superior', last: 'Hoy' }, { name: 'Milagros', surname: 'León', routine: 'Tren superior', last: 'Hace 3 días' }, { name: 'Mario', surname: 'Bautista', routine: 'Tren superior', last: 'Hace 4 días' }, { name: 'Ana', surname: 'Ramírez', routine: 'Sin asignar', last: '—' }],
      'entrenador:seguimiento': [{ name: 'Mario Bautista', routine: 'Tren superior', note: 'Aumentó 5 kg en press de banca', date: '2026-10-29', status: 'Al día' }, { name: 'Ana Ramírez', routine: 'Pierna intensa', note: 'Buena resistencia en el circuito', date: '2026-10-28', status: 'Al día' }, { name: 'Carolina Rivas', routine: 'Core y estabilidad', note: 'Buen entrenamiento de hoy', date: '2026-10-27', status: 'Pendiente' }, { name: 'Milagros León', routine: 'Tren superior', note: 'Sin notas recientes', date: '—', status: 'Sin iniciar' }]
    };
    return [...(records[key] || []), ...(this.addedRows[key] || [])]
      .map(row => ({ ...row, ...(this.rowEdits[this.recordKey(row)] || {}) }));
  }
  get filteredRows(): any[] { const term = this.searchTerm.trim().toLowerCase(); return this.rows.filter(row => !term || Object.values(row).some(value => String(value).toLowerCase().includes(term))); }
  get metrics(): any[] { return [{ label: 'Clientes activos', value: '1,248', delta: '+8.4%', icon: 'bi-people' }, { label: 'Ingresos del mes', value: 'S/ 24,680', delta: '+12.6%', icon: 'bi-currency-exchange' }, { label: 'Nuevas membresías', value: '28', delta: '+12.6%', icon: 'bi-card-checklist' }, { label: 'Membresías por vencer', value: '5', delta: '+2.5%', icon: 'bi-hourglass-split' }]; }
  get chartBars(): any[] { return [{ month: 'Ene', value: 42 }, { month: 'Feb', value: 53 }, { month: 'Mar', value: 47 }, { month: 'Abr', value: 64 }, { month: 'May', value: 60 }, { month: 'Jun', value: 70 }, { month: 'Jul', value: 63 }, { month: 'Ago', value: 82 }, { month: 'Sep', value: 72 }, { month: 'Oct', value: 90 }, { month: 'Nov', value: 80 }, { month: 'Dic', value: 100 }]; }
  get activities(): any[] { return [{ title: 'Nuevo cliente', detail: 'María López', time: 'Hace 8 min', kind: 'red' }, { title: 'Venta registrada', detail: 'Proteína Whey', time: 'Hace 21 min', kind: 'green' }, { title: 'Renovación', detail: 'Carlos Ramos', time: 'Hace 34 min', kind: 'blue' }, { title: 'Rutina asignada', detail: 'Luis Torres', time: 'Hace 52 min', kind: 'gold' }]; }
  get adminQuickLinks(): any[] { return [{ label: 'Agregar usuario', path: 'usuarios', icon: 'bi-person-plus' }, { label: 'Registrar cliente', path: 'clientes', icon: 'bi-person-add' }, { label: 'Ver membresías', path: 'membresias', icon: 'bi-card-checklist' }, { label: 'Gestionar productos', path: 'productos', icon: 'bi-box-seam' }]; }
  get exerciseFilters(): string[] { return ['Todos', 'Fuerza', 'Cardio', 'Flexibilidad', 'Calistenia']; }
  get productFilters(): string[] { return ['Todos', 'Suplementos', 'Accesorios', 'Ropa', 'Snacks']; }
  get exerciseRows(): any[] {
    return [
      { name: 'Press de banca', category: 'Fuerza', group: 'Pecho', level: 'Medio', icon: 'bi-person-arms-up', gif: 'assets/exercises/press_de_banca.gif', description: 'Ejercicio de empuje horizontal para fortalecer principalmente el pecho.', instructions: 'Mantén la espalda apoyada, controla el descenso y empuja sin bloquear los codos.' },
      { name: 'Remo con barra', category: 'Fuerza', group: 'Espalda', level: 'Medio', icon: 'bi-person-arms-up', gif: 'assets/exercises/remo_con_barra.gif', description: 'Movimiento de tracción para trabajar la espalda y los brazos.', instructions: 'Inclina el torso con la espalda neutra y lleva la barra hacia el abdomen.' },
      { name: 'Sentadilla', category: 'Fuerza', group: 'Piernas', level: 'Alto', icon: 'bi-person-arms-up', gif: 'assets/exercises/sentadilla.gif', description: 'Ejercicio compuesto para fortalecer piernas y glúteos.', instructions: 'Mantén el pecho erguido y las rodillas alineadas con los pies.' },
      { name: 'Flexiones', category: 'Fuerza', group: 'Pecho', level: 'Bajo', icon: 'bi-person-arms-up', gif: 'assets/exercises/flexiones.gif', description: 'Ejercicio de empuje con el peso corporal para pecho, hombros y tríceps.', instructions: 'Alinea cabeza, espalda y cadera; baja con control.' },
      { name: 'Peso muerto', category: 'Fuerza', group: 'Espalda y piernas', level: 'Alto', icon: 'bi-person-arms-up', gif: 'assets/exercises/peso_muerto.gif', description: 'Levantamiento que desarrolla fuerza en la cadena posterior.', instructions: 'Mantén la barra cerca del cuerpo y conserva la espalda neutra.' },
      { name: 'Salto de soga', category: 'Cardio', group: 'Resistencia', level: 'Bajo', icon: 'bi-heart-pulse', description: 'Trabajo cardiovascular de coordinación y ritmo.', instructions: 'Salta bajo, gira la cuerda con las muñecas y aterriza suavemente.' },
      { name: 'Rodillas altas', category: 'Cardio', group: 'Resistencia', level: 'Medio', icon: 'bi-heart-pulse', description: 'Carrera en el sitio elevando las rodillas para trabajar ritmo y resistencia.', instructions: 'Alterna las piernas con control y activa el abdomen durante el movimiento.' },
      { name: 'Estiramiento de mariposa', category: 'Flexibilidad', group: 'Cadera', level: 'Bajo', icon: 'bi-universal-access', description: 'Estiramiento sentado para trabajar la movilidad de la cadera y la parte interna de los muslos.', instructions: 'Junta las plantas de los pies, mantén la espalda larga y acerca suavemente las rodillas al suelo.' },
      { name: 'Estiramiento de cobra', category: 'Flexibilidad', group: 'Abdomen y espalda', level: 'Bajo', icon: 'bi-universal-access', description: 'Extensión suave del tronco para movilizar el abdomen y la zona frontal del cuerpo.', instructions: 'Desde boca abajo, apoya las manos y eleva el pecho suavemente sin forzar la zona lumbar.' },
      { name: 'Dominadas', category: 'Calistenia', group: 'Espalda y brazos', level: 'Alto', icon: 'bi-person-arms-up', gif: 'assets/exercises/dominadas.gif', description: 'Tracción con el peso corporal para espalda y brazos.', instructions: 'Inicia con los hombros activos y sube sin balancear el cuerpo.' },
      { name: 'Fondos en paralelas', category: 'Calistenia', group: 'Pecho y tríceps', level: 'Medio', icon: 'bi-person-arms-up', gif: 'assets/exercises/fondos_en_paralelas.gif', description: 'Ejercicio de empuje con peso corporal para pecho y tríceps.', instructions: 'Desciende hasta donde mantengas control y empuja con estabilidad.' },
      { name: 'Abdominales crunch', category: 'Calistenia', group: 'Abdomen', level: 'Bajo', icon: 'bi-person-arms-up', gif: 'assets/exercises/abdominales_crunch.gif', description: 'Ejercicio abdominal básico para trabajar la flexión controlada del tronco.', instructions: 'Con las rodillas flexionadas, eleva ligeramente los hombros contrayendo el abdomen y baja con control.' },
      { name: 'Sentadilla pistol asistida', category: 'Calistenia', group: 'Piernas', level: 'Alto', icon: 'bi-person-arms-up', gif: 'assets/exercises/sentadilla_pistol_asistida.gif', description: 'Progresión unilateral de sentadilla con apoyo para controlar el equilibrio.', instructions: 'Usa un soporte, baja con control y trabaja dentro de un rango cómodo.' }
    ];
  }
  get filteredExercises(): any[] { return this.exerciseRows.filter(row => (this.activeFilter === 'Todos' || row.category === this.activeFilter) && (!this.searchTerm || row.name.toLowerCase().includes(this.searchTerm.toLowerCase()))); }
  get routineRows(): any[] { return [{ name: 'Tren superior', exercises: 4, clients: '1 cliente', updated: '2026-10-05' }, { name: 'Pierna intensa', exercises: 3, clients: '2 clientes', updated: '2026-09-01' }, { name: 'Core y estabilidad', exercises: 2, clients: '1 cliente', updated: '2026-08-30' }, { name: 'Quema grasa', exercises: 3, clients: 'Sin asignar', updated: '2026-08-30' }]; }
  get clientExercises(): any[] { return [{ number: '01', name: 'Press de banca', group: 'Pecho', level: 'Medio', sets: 4, reps: 10, rest: '60s' }, { number: '02', name: 'Remo con barra', group: 'Espalda', level: 'Medio', sets: 4, reps: 10, rest: '60s' }, { number: '03', name: 'Press inclinado', group: 'Pecho', level: 'Medio', sets: 3, reps: 12, rest: '45s' }, { number: '04', name: 'Remo con mancuerna', group: 'Espalda', level: 'Medio', sets: 3, reps: 12, rest: '45s' }]; }
  get progressNotes(): any[] { return [{ date: '29 OCT 2026', title: 'Aumentaste 5 kg en press de banca', text: '¡Muy bien! Sigue así con tu rutina.' }, { date: '26 OCT 2026', title: 'Recomendación: mejora técnica de remo', text: 'Controla el movimiento en cada repetición.' }, { date: '22 OCT 2026', title: 'Buen ritmo esta semana', text: 'Mantén la constancia en tus entrenamientos.' }]; }
  get filteredProducts(): any[] { return this.products.filter(item => (this.activeFilter === 'Todos' || item.category === this.activeFilter) && (!this.searchTerm || item.name.toLowerCase().includes(this.searchTerm.toLowerCase()))); }
  get products(): any[] { return [{ name: 'Whey Pro 3kg Chocolate', category: 'Suplementos', price: 90, status: 'Disponible', icon: 'bi-box-seam' }, { name: 'Guantes deportivos', category: 'Accesorios', price: 20, status: 'Disponible', icon: 'bi-hand' }, { name: 'Whey Pro 3kg Vainilla', category: 'Suplementos', price: 90, status: 'Disponible', icon: 'bi-box-seam' }, { name: 'Polo deportivo', category: 'Ropa', price: 59, status: 'Stock bajo', icon: 'bi-bag' }, { name: 'Barra energética', category: 'Snacks', price: 8, status: 'Agotado', icon: 'bi-basket' }, { name: 'Proteína Whey', category: 'Suplementos', price: 75, status: 'Disponible', icon: 'bi-box-seam' }]; }
  get cartCount(): number { return this.cart.reduce((sum, item) => sum + item.quantity, 0); }
  get cartTotal(): number { return this.cart.reduce((sum, item) => sum + item.price * item.quantity, 0); }
  get paymentRows(): any[] { return [{ date: '2026-09-07', plan: 'Premium', amount: 'S/ 69.99', method: 'Efectivo' }, { date: '2026-08-07', plan: 'Básico', amount: 'S/ 39.99', method: 'Efectivo' }, { date: '2026-07-07', plan: 'Pro', amount: 'S/ 99.99', method: 'Tarjeta' }, { date: '2026-06-07', plan: 'Pro', amount: 'S/ 99.99', method: 'Yape' }]; }
  get modalDescription(): string { return 'Completa la información para guardar los cambios en la demostración.'; }
  get modalSubmitLabel(): string { return this.modalTitle.toLowerCase().includes('cobrar') || this.modalTitle.toLowerCase().includes('venta') ? 'Confirmar cobro' : 'Guardar'; }
  get modalFields(): any[] {
    if (this.cachedModalTitle === this.modalTitle) return this.cachedModalFields;
    this.cachedModalTitle = this.modalTitle;
    this.cachedModalFields = this.createModalFields();
    return this.cachedModalFields;
  }
  private createModalFields(): any[] {
    if (this.modalTitle.includes('usuario')) return [{ label: 'Nombre', key: 'name', placeholder: 'Nombre' }, { label: 'Apellido', key: 'surname', placeholder: 'Apellido' }, { label: 'Correo electrónico', key: 'email', type: 'email' }, { label: 'Rol', key: 'role', type: 'select', options: ['Administrador', 'Recepcionista', 'Entrenador'] }, { label: 'DNI', key: 'dni' }, { label: 'Teléfono', key: 'phone' }];
    if (this.modalTitle.includes('cliente') || this.modalTitle.includes('datos')) return [{ label: 'Nombre', key: 'name' }, { label: 'Apellido', key: 'surname' }, { label: 'Correo electrónico', key: 'email', type: 'email' }, { label: 'DNI', key: 'dni' }, { label: 'Plan', key: 'plan', type: 'select', options: ['Básico', 'Premium', 'Pro'] }];
    if (this.modalTitle.includes('producto')) return [{ label: 'Nombre del producto', key: 'name' }, { label: 'Categoría', key: 'category', type: 'select', options: this.productFilters.slice(1) }, { label: 'Precio', key: 'price', type: 'number' }, { label: 'Stock inicial', key: 'stock', type: 'number' }, { label: 'Descripción', key: 'description', type: 'textarea' }];
    if (this.modalTitle.includes('ejercicio')) return [{ label: 'Nombre del ejercicio', key: 'name' }, { label: 'Grupo muscular', key: 'group', type: 'select', options: ['Pecho', 'Espalda', 'Pierna', 'Hombro', 'Cardio'] }, { label: 'Nivel', key: 'level', type: 'select', options: ['Bajo', 'Medio', 'Alto'] }, { label: 'Descripción', key: 'description', type: 'textarea' }, { label: 'Indicaciones', key: 'instructions', type: 'textarea' }];
    if (this.modalTitle.toLowerCase().includes('plan')) return [{ label: 'Nombre del plan', key: 'name', placeholder: 'Plan Premium' }, { label: 'Precio mensual', key: 'price', type: 'number' }, { label: 'Duración en días', key: 'duration', type: 'number' }, { label: 'Beneficios', key: 'benefits', type: 'textarea' }];
    if (this.modalTitle.includes('membresía')) return [{ label: 'Cliente', key: 'client', placeholder: 'Buscar cliente' }, { label: 'Plan', key: 'plan', type: 'select', options: ['Básico', 'Premium', 'Pro'] }, { label: 'Método de pago', key: 'method', type: 'select', options: ['Efectivo', 'Tarjeta', 'Yape'] }];
    if (this.modalTitle.includes('seguimiento')) return [{ label: 'Cliente', key: 'client', type: 'select', options: ['Mario Bautista', 'Ana Ramírez', 'Melani Camacho'] }, { label: 'Fecha', key: 'date', type: 'date' }, { label: 'Nota u observación', key: 'note', type: 'textarea' }];
    return [{ label: 'Cliente', key: 'client', placeholder: 'Selecciona un cliente' }, { label: 'Nota', key: 'note', type: 'textarea' }];
  }

  get isStatus(): (value: string) => boolean { return value => ['Activo', 'Inactivo', 'Vencido', 'Pendiente', 'Pagado', 'Ingreso', 'Al día', 'Sin iniciar', 'Stock bajo', 'Disponible', 'Agotado'].includes(value); }
  trackByRecord = (_index: number, row: any): string => this.recordKey(row);
  statusClass(value: string): string { const v = value.toLowerCase(); if (v === 'activo' || v === 'pagado' || v === 'ingreso' || v === 'al día' || v === 'disponible') return 'status-active'; if (v === 'vencido' || v === 'agotado' || v === 'inactivo' || v.includes('sin iniciar')) return 'status-danger'; if (v === 'pendiente' || v.includes('bajo')) return 'status-pending'; return 'status-blue'; }
  navigate(path: string): void { void this.router.navigate(['/', this.role, path]); }
  goProfile(): void { this.profileOpen = false; this.navigate(this.role === 'cliente' ? 'perfil' : this.menu[0].path); }
  openModal(title: string): void { this.modalTitle = title; this.formData = {}; this.modalOpen = true; }
  saveModal(): void {
    if (this.modalTitle.toLowerCase().includes('asistencia')) { this.toast('Asistencia registrada'); }
    else if (this.modalSubmitLabel === 'Confirmar cobro') { this.toast('Pago registrado correctamente'); }
    else if (this.modalTitle.toLowerCase().includes('ejercicio')) { this.toast('Ejercicio guardado en la biblioteca'); }
    else if (this.modalTitle.toLowerCase().includes('rutina')) { this.toast('Rutina guardada correctamente'); }
    else {
      const key = `${this.role}:${this.section}`;
      const form = this.formData;
      const entry: any = { ...form, name: form['name'] || form['client'] || form['product'] || '', surname: form['surname'] || '', status: 'Activo' };
      if (this.section === 'productos') { entry['product'] = form['name'] || ''; entry['price'] = `S/ ${form['price'] || '0.00'}`; entry['stock'] = form['stock'] || 0; entry['status'] = Number(form['stock'] || 0) > 0 ? 'Disponible' : 'Agotado'; }
      if (this.section === 'membresias' && this.role === 'admin') { entry['plan'] = form['name']?.startsWith('Plan ') ? form['name'] : `Plan ${form['name'] || form['plan'] || 'Nuevo'}`; entry['price'] = `S/ ${form['price'] || '0.00'}`; entry['duration'] = `${form['duration'] || 30} días`; }
      if (this.section === 'membresias' && this.role === 'recepcion') { const parts = (form['client'] || '').split(' '); entry['name'] = parts[0] || 'Nuevo'; entry['surname'] = parts.slice(1).join(' ') || 'Cliente'; entry['plan'] = form['plan'] || 'Premium'; entry['price'] = 'S/ 69.99'; entry['method'] = form['method'] || 'Efectivo'; entry['status'] = 'Pagado'; }
      if (this.editingKey) this.rowEdits[this.editingKey] = { ...entry };
      else (this.addedRows[key] ||= []).push(entry);
      this.toast(this.editingKey ? 'Cambios guardados correctamente' : `${this.modalTitle.replace('Agregar', '').replace('Registrar', '').trim()} agregado correctamente`);
    }
    this.editingKey = null;
    this.modalOpen = false;
  }
  rowAction(action: string, row: any): void {
    const recordId = this.recordKey(row);
    if (action === 'Eliminar') { this.toast('Modo demostración: los registros de ejemplo se conservan'); return; }
    if (action === 'Editar') {
      const noun = this.section === 'clientes' ? 'cliente' : this.section === 'usuarios' ? 'usuario' : this.section === 'productos' ? 'producto' : 'membresía';
      this.openModal('Editar ' + noun);
      this.editingKey = recordId;
      this.formData = { name: row.name || row.product || row.plan || '', surname: row.surname || '', email: row.email || '', role: row.role || '', plan: row.plan || '', category: row.category || '', price: String(row.price || '').replace('S/ ', ''), stock: String(row.stock || '') };
      return;
    }
    this.toast(`${row.name || row.product || row.plan}: ${row.status || row.routine || 'Detalle consultado'}`);
  }
  private recordKey(row: any): string { return String(row.name || row.product || row.plan || row.email || 'record'); }
  isTableScreenAction(): void { this.openModal(this.primaryAction); }
  toast(message: string): void { this.toastText = message; if (this.toastTimer) clearTimeout(this.toastTimer); this.toastTimer = setTimeout(() => this.toastText = '', 3200); }
  addToCart(product: any): void { const found = this.cart.find(item => item.name === product.name); if (found) found.quantity++; else this.cart.push({ ...product, quantity: 1 }); }
  changeQuantity(item: any, delta: number): void { item.quantity += delta; if (item.quantity <= 0) this.cart = this.cart.filter(product => product !== item); }
  payNow(): void { this.toast(`Pago con ${this.paymentMethod} iniciado`); }
  ask(question: string): void { this.chatInput = question; this.sendMessage(); }
  sendMessage(): void { const message = this.chatInput.trim(); if (!message) return; this.chatMessages.push({ text: message, from: 'user' }); this.chatInput = ''; setTimeout(() => this.chatMessages.push({ text: 'Para un plan nutricional personalizado, consulta con un profesional. Como orientación general, prioriza alimentos variados, agua y una buena recuperación después del entrenamiento.', from: 'ai' }), 500); }
  addRoutineExercise(): void { if (this.selectedExerciseName) { this.builderExercises.push(`${this.selectedExerciseName} · ${this.builderSets || 4}×${this.builderReps || 10} · ${this.builderRest || 60}s`); this.selectedExerciseName = ''; this.builderSets = ''; this.builderReps = ''; this.builderRest = ''; } }
  removeBuilderExercise(exercise: string): void { this.builderExercises = this.builderExercises.filter(item => item !== exercise); }
  saveRoutine(): void { if (!this.routineName.trim() || !this.builderExercises.length) { this.toast('Agrega un nombre y al menos un ejercicio'); return; } this.toast(`Rutina “${this.routineName}” guardada`); this.routineName = ''; this.builderExercises = []; }
  removeRoutine(row: any): void { this.toast(`Rutina “${row.name}” eliminada de la demo`); }
}
