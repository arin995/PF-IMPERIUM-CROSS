import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AuthService, UserRole } from '../services/auth.service';
import { BrandComponent } from '../shared/components/brand.component';

@Component({
  selector: 'app-login', standalone: true, imports: [CommonModule, FormsModule, RouterLink, BrandComponent],
  template: `
    <main class="login-page"><a routerLink="/" class="back-home"><i class="bi bi-arrow-left"></i> Volver al inicio</a>
      <section class="login-art"><img src="assets/imperium-team.jpg" alt="Comunidad Imperium Cross"><div class="login-art-shade"></div><div class="login-brand"><app-brand /></div><div class="login-art-copy"><span class="eyebrow light">FUERZA · COMUNIDAD · DISCIPLINA</span><h1>El progreso<br>empieza con<br><em>una decisión.</em></h1></div></section>
      <section class="login-panel"><div class="login-card"><a class="brand login-card-brand" routerLink="/"><app-brand /></a><span class="eyebrow">BIENVENIDO DE VUELTA</span><h2>Inicia sesión</h2><p>Ingresa a tu espacio Imperium Cross.</p>
        <form (ngSubmit)="submit()"><label for="user">Usuario o correo</label><input id="user" name="user" [(ngModel)]="username" placeholder="nombre@imperiumcross.com" autocomplete="username" required><label for="password">Contraseña</label><div class="password-input"><input id="password" name="password" [(ngModel)]="password" [type]="showPassword ? 'text' : 'password'" placeholder="Ingresa tu contraseña" autocomplete="current-password" required><button type="button" (click)="showPassword = !showPassword" [attr.aria-label]="showPassword ? 'Ocultar contraseña' : 'Mostrar contraseña'"><i class="bi" [class.bi-eye]="!showPassword" [class.bi-eye-slash]="showPassword"></i></button></div>
          <button type="button" class="forgot-link" (click)="forgot = !forgot">¿Olvidaste tu contraseña?</button>
          <div class="forgot-box" *ngIf="forgot && !recoverySent"><strong>¿Olvidaste tu contraseña?</strong><p>Te enviaremos instrucciones para restablecer el acceso.</p><div><input type="email" name="recoveryEmail" [(ngModel)]="recoveryEmail" placeholder="Tu correo electrónico"><button type="button" class="btn-red" (click)="sendRecovery()">Enviar enlace</button></div></div>
          <div class="forgot-box recovery-state" *ngIf="forgot && recoverySent && !showResetForm && !recoveryComplete"><i class="bi bi-envelope-check"></i><strong>Revisa tu correo</strong><p>Si el correo está registrado, recibirás un enlace de recuperación.</p><button type="button" class="btn-outline-red" (click)="showResetForm = true">Simular enlace de recuperación</button></div>
          <div class="forgot-box" *ngIf="forgot && showResetForm && !recoveryComplete"><strong>Crea una nueva contraseña</strong><div><input type="password" name="newPassword" [(ngModel)]="newPassword" placeholder="Nueva contraseña"><input type="password" name="confirmPassword" [(ngModel)]="confirmPassword" placeholder="Confirmar contraseña"><small class="form-error" *ngIf="resetError">{{ resetError }}</small><button type="button" class="btn-red" (click)="saveNewPassword()">Restablecer contraseña</button></div></div>
          <div class="forgot-box recovery-state" *ngIf="forgot && recoveryComplete"><i class="bi bi-check-circle-fill"></i><strong>¡Contraseña actualizada!</strong><p>Tu contraseña se restableció correctamente.</p><button type="button" class="btn-red" (click)="finishRecovery()">Volver a iniciar sesión</button></div>
          <button class="btn-red login-submit" type="submit">Iniciar sesión <i class="bi bi-arrow-right"></i></button>
        </form>
        <div class="demo-access"><div class="divider"><span>ACCESO DE DEMOSTRACIÓN</span></div><label for="role">Explora la interfaz como</label><select id="role" name="role" [(ngModel)]="role"><option value="admin">Administrador</option><option value="recepcion">Recepcionista</option><option value="entrenador">Entrenador</option><option value="cliente">Cliente</option></select><button type="button" class="btn-outline-red" (click)="demo()">Entrar a la demo <i class="bi bi-arrow-up-right"></i></button><small>La demo usa datos de ejemplo y no requiere backend.</small></div>
      </div><p class="login-footnote">¿Necesitas ayuda? <a href="mailto:recepcion@imperiumcross.com">Contacta a recepción</a></p></section>
    </main>
  `
})
export class LoginComponent {
  username = '';
  password = '';
  role: UserRole = 'cliente';
  showPassword = false;
  forgot = false;
  recoveryEmail = '';
  recoverySent = false;
  showResetForm = false;
  recoveryComplete = false;
  newPassword = '';
  confirmPassword = '';
  resetError = '';
  constructor(private auth: AuthService) {}
  submit(): void {
    if (this.username.trim() && this.password.trim()) this.auth.login(this.username.split('@')[0].replace(/[._-]/g, ' '), this.role);
  }
  demo(): void { this.auth.login('', this.role); }
  sendRecovery(): void { if (this.recoveryEmail.trim()) this.recoverySent = true; }
  saveNewPassword(): void {
    if (this.newPassword.length < 8) { this.resetError = 'Usa al menos 8 caracteres.'; return; }
    if (this.newPassword !== this.confirmPassword) { this.resetError = 'Las contraseñas no coinciden.'; return; }
    this.resetError = '';
    this.recoveryComplete = true;
  }
  finishRecovery(): void { this.forgot = false; this.recoverySent = false; this.showResetForm = false; this.recoveryComplete = false; this.newPassword = ''; this.confirmPassword = ''; }
}
