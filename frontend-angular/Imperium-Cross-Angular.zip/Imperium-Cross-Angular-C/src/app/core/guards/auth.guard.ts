import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService, UserRole } from '../../services/auth.service';

export const roleGuard: CanActivateFn = route => {
  const auth = inject(AuthService);
  const router = inject(Router);
  const role = route.paramMap.get('role') as UserRole | null;
  const user = auth.user();
  if (!user) { void router.navigate(['/login']); return false; }
  if (role && user.role !== role) { void router.navigate([`/${user.role}/dashboard`]); return false; }
  return true;
};
