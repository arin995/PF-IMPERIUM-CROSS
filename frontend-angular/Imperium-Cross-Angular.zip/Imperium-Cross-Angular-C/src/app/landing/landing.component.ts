import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { BrandComponent } from '../shared/components/brand.component';

@Component({
  selector: 'app-landing', standalone: true, imports: [RouterLink, BrandComponent],
  template: `
    <header class="landing-header"><a class="brand" routerLink="/"><app-brand /></a>
      <nav aria-label="Navegación principal">
        <a href="#inicio" (click)="scrollToSection($event, 'inicio')">Inicio</a>
        <a href="#nosotros" (click)="scrollToSection($event, 'nosotros')">Nosotros</a>
        <a href="#planes" (click)="scrollToSection($event, 'planes')">Planes</a>
        <a href="#entrenadores" (click)="scrollToSection($event, 'entrenadores')">Entrenadores</a>
        <a href="#testimonios" (click)="scrollToSection($event, 'testimonios')">Testimonios</a>
      </nav>
      <a class="btn-red contact-link" href="#contacto">Contáctanos</a><a class="login-link" routerLink="/login">Ingresar <i class="bi bi-arrow-up-right"></i></a>
    </header>
    <main>
      <section class="hero" id="inicio"><img src="assets/imperium-team.jpg" alt="Comunidad de Imperium Cross reunida en el gimnasio"><div class="hero-shade"></div><div class="hero-content"><span class="eyebrow light">FUERZA · COMUNIDAD · DISCIPLINA</span><h1>Transforma tu rutina.<br><em>Supera tus límites.</em></h1><p>Entrena, diviértete y mejora junto a una comunidad que te impulsa cada día.</p><div class="hero-actions"><a class="btn-red" href="#planes">Descubre nuestros planes <i class="bi bi-arrow-right"></i></a><a class="btn-glass" href="#nosotros">Conócenos</a></div><div class="hero-proof"><div class="avatar-stack"><span>IC</span><span>IC</span><span>IC</span></div><span><b>Entrena con propósito</b><small>Tu mejor versión empieza aquí</small></span></div></div><div class="hero-side-note">IMPERIUM CROSSFIT · LIMA</div></section>
      <section class="intro-section" id="nosotros"><div><span class="eyebrow">MÁS QUE UN GIMNASIO</span><h2>Un espacio para construir<br>tu <em>mejor versión.</em></h2></div><p>Entrenamiento, acompañamiento y una comunidad que celebra cada avance. Encuentra el ritmo que funciona para ti y sigue progresando.</p></section>
      <section class="feature-strip"><article><span>01</span><h3>Entrena a tu manera</h3><p>Planes pensados para tus objetivos, tu nivel y tu ritmo.</p></article><article><span>02</span><h3>Coaches que te acompañan</h3><p>Orientación cercana para entrenar con confianza.</p></article><article><span>03</span><h3>Una comunidad que suma</h3><p>Comparte el esfuerzo y celebra cada logro.</p></article></section>
      <section class="plans-section" id="planes"><div class="section-heading"><div><span class="eyebrow">ELIGE TU CAMINO</span><h2>Un plan para cada <em>objetivo.</em></h2></div><p>Conoce las opciones disponibles en recepción.</p></div><div class="plan-cards"><article><span class="plan-kicker">PARA EMPEZAR</span><h3>Básico</h3><p>Una base constante para crear el hábito y ganar fuerza.</p><strong>S/ 39.99 <small>/ mes</small></strong><a routerLink="/login">Conocer más <i class="bi bi-arrow-up-right"></i></a></article><article class="plan-featured"><span class="plan-kicker">MÁS ELEGIDO</span><h3>Premium</h3><p>Entrena con acompañamiento y accede a beneficios exclusivos.</p><strong>S/ 69.99 <small>/ mes</small></strong><a routerLink="/login">Conocer más <i class="bi bi-arrow-up-right"></i></a></article><article><span class="plan-kicker">MÁXIMO IMPULSO</span><h3>Pro</h3><p>Más flexibilidad para mantenerte activo y avanzar.</p><strong>S/ 99.99 <small>/ mes</small></strong><a routerLink="/login">Conocer más <i class="bi bi-arrow-up-right"></i></a></article></div></section>
      <section class="coaches-section" id="entrenadores"><span class="eyebrow light">EL EQUIPO QUE TE IMPULSA</span><h2>Tu esfuerzo.<br><em>Nuestro acompañamiento.</em></h2><a routerLink="/login" class="btn-glass">Conoce a tu coach <i class="bi bi-arrow-right"></i></a></section>
      <section class="testimonial-section" id="testimonios"><span class="eyebrow">LA COMUNIDAD IMPERIUM</span><h2>Los pequeños avances<br>también cuentan.</h2><blockquote>“Cada entrenamiento es una oportunidad para superarme. Aquí encontré la motivación y el equipo para hacerlo.”</blockquote><strong>Comunidad Imperium Cross</strong></section>
      <section class="contact-section" id="contacto"><div><span class="eyebrow light">EMPIEZA HOY</span><h2>El siguiente paso<br>es tuyo.</h2></div><a routerLink="/login" class="btn-red">Hablemos en recepción <i class="bi bi-arrow-right"></i></a></section>
    </main><footer class="landing-footer"><a class="brand" routerLink="/"><app-brand /></a><span>Fuerza · Comunidad · Disciplina</span><a routerLink="/login">Acceso de miembros</a><small>© 2026 Imperium Cross</small></footer>
  `
})
export class LandingComponent {
  scrollToSection(event: MouseEvent, sectionId: string): void {
    event.preventDefault();
    const section = document.getElementById(sectionId);
    if (!section) return;

    history.replaceState(null, '', `#${sectionId}`);
    section.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}
