export const RECEPTION_MENU = [
  { label: 'Clientes', path: 'clientes', icon: 'bi-people' },
  { label: 'Membresías y pagos', path: 'membresias', icon: 'bi-credit-card' },
  { label: 'Asistencia', path: 'asistencia', icon: 'bi-calendar-check' },
  { label: 'Venta de productos', path: 'productos', icon: 'bi-bag' }
];
