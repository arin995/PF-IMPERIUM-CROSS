export const TRAINER_MENU = [
  { label: 'Mis clientes', path: 'mis-clientes', icon: 'bi-people' },
  { label: 'Ejercicios', path: 'ejercicios', icon: 'bi-activity' },
  { label: 'Rutinas', path: 'rutinas', icon: 'bi-list-check' },
  { label: 'Seguimiento', path: 'seguimiento', icon: 'bi-graph-up-arrow' }
];
