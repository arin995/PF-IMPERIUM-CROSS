# Imperium Cross — Frontend

Frontend Angular para Imperium Cross, desarrollado a partir de las pantallas de referencia y del landing compartido.

## Tecnologías

- Angular 20 y TypeScript
- SCSS
- Bootstrap 5 y Bootstrap Icons
- Angular Router y formularios template-driven
- RxJS para el estado de sesión
- Datos de demostración en el navegador

## Ejecutar

Requiere Node.js 20.19 o posterior.

```bash
npm install
npm start
```

La aplicación se abre en `http://localhost:4200`. Desde **Ingresar**, puedes entrar a la demo como administrador, recepcionista, entrenador o cliente. El acceso demo no requiere backend.

## Organización

```text
src/app/
  admin/       navegación y funciones del administrador
  auth/        inicio de sesión y acceso demo
  client/      navegación y espacio del cliente
  core/        guards de acceso por rol
  landing/     página pública de Imperium Cross
  reception/   navegación y espacio de recepción
  services/    servicio de sesión de demostración
  shared/      componentes reutilizables
  trainer/     navegación y espacio del entrenador
  workspace/   shell autenticado y pantallas por rol
```

La sesión demo se guarda en `localStorage`. Formularios, búsqueda, filtros, carrito y navegación trabajan con datos locales. El ZIP no incluía backend ni contrato de API, por lo que aún no se han conectado servicios HTTP reales, pagos reales, envío de correos ni autenticación de producción. Los datos visibles son de muestra.

El cliente HTTP genérico está preparado en `src/app/services/api.service.ts`; su URL de desarrollo (`http://localhost:8080/api`) se configura en `src/environments/environment.ts`.
